package labexam;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class NewTest {
	public static WebDriver d;
	
  @Test
  public void open() {
	  System.setProperty("webdriver.chrome.driver","D:\\Selenium Data\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		 d=new ChromeDriver();
		 d.get("https://automationexercise.com/login");
		 d.manage().window().maximize();
		 System.out.println("-----------------------------------------------------");
		  String u = d.getCurrentUrl();
		  System.out.println("current url" +u);

		  System.out.println("-----------------------------------------------------");
  }
  
  @Test(priority = 1)
  public void login() {
	  d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[3]/div[1]/form[1]/input[2]")).sendKeys("Aishwarya");
	  d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[3]/div[1]/form[1]/input[3]")).sendKeys("aishwarya12@gmail.com");
	  d.findElement(By.xpath("//button[contains(text(),'Signup')]")).click();
  }
  
  @Test(priority = 2)
  public void reg() {
	  d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[2]/label[1]")).click();
	  d.findElement(By.xpath("//input[@id='password']")).sendKeys("aish1234");
	  Select dt = new Select(d.findElement(By.xpath("//select[@id='days']")));
	  dt.selectByValue("2");
	  Select mon = new Select(d.findElement(By.xpath("//select[@id='months']")));
	  mon.selectByIndex(12);
	  Select yr = new Select(d.findElement(By.xpath("//select[@id='years']")));
	  yr.selectByValue("2000");
	  d.findElement(By.id("newsletter")).click();
	  d.findElement(By.xpath("//input[@id='first_name']")).sendKeys("Aishwarya");
	  d.findElement(By.xpath("//input[@id='last_name']")).sendKeys("Bhattalwar");
	  d.findElement(By.xpath("//input[@id='address1']")).sendKeys("MET BKC");
	  d.findElement(By.xpath("//input[@id='state']")).sendKeys("Maharashtra");
	  d.findElement(By.xpath("//input[@id='city']")).sendKeys("Nashik");
	  d.findElement(By.xpath("//input[@id='zipcode']")).sendKeys("221006");
	  d.findElement(By.xpath("//input[@id='mobile_number']")).sendKeys("9876543210");
	  d.findElement(By.xpath("//button[contains(text(),'Create Account')]")).click();
	  d.findElement(By.xpath("//a[contains(text(),'Continue')]")).click();
	  
	  d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[2]")).sendKeys("aishwarya12@gmail.com");
	  String str = d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[2]")).getAttribute("value");
	  System.out.println(str);
	  d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[3]")).sendKeys("aish1234");
	  String str1 = d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[3]")).getAttribute("value");
	  System.out.println(str1);
	  d.findElement(By.xpath("//button[contains(text(),'Login')]")).click();

	   
	  

  }
  
}
